<?php
require_once dirname(__DIR__, 3) . '/lib/bootstrap.php';

require_method('POST', 'PUT', 'PATCH');
require_super_admin();
$body = read_json_body();

$tenantPublicId = trim((string) ($body['id'] ?? $body['tenantId'] ?? $body['tenant_id'] ?? ''));
if ($tenantPublicId === '') {
    json_error('id (tenant public_id) is required', 422);
}

$pdo = db();
$tStmt = $pdo->prepare('SELECT * FROM tenants WHERE public_id = ? LIMIT 1');
$tStmt->execute([$tenantPublicId]);
$tenant = $tStmt->fetch();
if (!$tenant) {
    json_error('Tenant not found', 404);
}

$name = array_key_exists('name', $body)
    ? trim((string) $body['name'])
    : (string) $tenant['name'];
$subdomain = array_key_exists('subdomain', $body)
    ? strtolower(trim((string) $body['subdomain']))
    : (string) $tenant['subdomain'];
$subdomain = preg_replace('/[^a-z0-9\-]/', '', $subdomain) ?? '';
$tier = array_key_exists('tier', $body)
    ? trim((string) $body['tier'])
    : (string) $tenant['tier'];
$status = array_key_exists('status', $body)
    ? trim((string) $body['status'])
    : (string) $tenant['status'];
$capacity = array_key_exists('capacity', $body)
    ? (int) $body['capacity']
    : (int) $tenant['capacity'];

if ($name === '') {
    json_error('name is required', 422);
}
if ($subdomain === '') {
    json_error('subdomain is required', 422);
}
if (!in_array($tier, ['Basic', 'Premium', 'Enterprise'], true)) {
    json_error('tier must be Basic, Premium, or Enterprise', 422);
}
if (!in_array($status, ['Active', 'Trial', 'Overdue', 'Suspended'], true)) {
    json_error('Invalid status', 422);
}
if ($capacity < 1) {
    json_error('capacity must be at least 1', 422);
}

$students = (int) ($tenant['current_students'] ?? 0);
$countStmt = $pdo->prepare('SELECT COUNT(*) AS c FROM students WHERE tenant_id = ?');
$countStmt->execute([(int) $tenant['id']]);
$liveCount = (int) ($countStmt->fetch()['c'] ?? 0);
$students = max($students, $liveCount);
if ($capacity < $students) {
    json_error("capacity cannot be below current enrolment ({$students})", 422);
}

if ($subdomain !== $tenant['subdomain']) {
    $dup = $pdo->prepare('SELECT id FROM tenants WHERE subdomain = ? AND id <> ? LIMIT 1');
    $dup->execute([$subdomain, (int) $tenant['id']]);
    if ($dup->fetch()) {
        json_error('Subdomain already taken', 409);
    }
}

$planStmt = $pdo->prepare('SELECT id FROM subscription_plans WHERE name = ? LIMIT 1');
$planStmt->execute([$tier]);
$plan = $planStmt->fetch();
$planId = $plan ? (int) $plan['id'] : ($tenant['plan_id'] ?? null);

$upd = $pdo->prepare(
    'UPDATE tenants
     SET name = ?, subdomain = ?, tier = ?, plan_id = ?, status = ?, capacity = ?
     WHERE id = ?'
);
$upd->execute([
    $name,
    $subdomain,
    $tier,
    $planId,
    $status,
    $capacity,
    (int) $tenant['id'],
]);

// Keep school_settings display name aligned when renamed
$ss = $pdo->prepare('UPDATE school_settings SET name = ? WHERE tenant_id = ?');
$ss->execute([$name, (int) $tenant['id']]);

$out = $pdo->prepare(
    'SELECT t.*,
            COALESCE(
              (SELECT COUNT(*) FROM students s WHERE s.tenant_id = t.id),
              t.current_students,
              0
            ) AS student_count
     FROM tenants t
     WHERE t.id = ?
     LIMIT 1'
);
$out->execute([(int) $tenant['id']]);

json_ok(map_sa_tenant($out->fetch()));
